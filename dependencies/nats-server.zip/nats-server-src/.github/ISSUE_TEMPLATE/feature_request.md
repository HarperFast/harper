---
name: Feature Request
about: Request a feature for the NATS Server
labels: 🎉 enhancement
---

## Feature Request

#### Use Case:

#### Proposed Change:

#### Who Benefits From The Change(s)?

#### Alternative Approaches

